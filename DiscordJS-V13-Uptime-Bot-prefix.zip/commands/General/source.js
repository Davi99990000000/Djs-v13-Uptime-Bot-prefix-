const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: 'source',
    aliases: ["sc", "bot-code"],
	category: "General",
	description: "Gives the source code link for the bot",
	usage: "",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {
		

     let embedSc = new MessageEmbed()
			 .setAuthor({ name: "Please read readme.md before use the code", iconURL: client.embed.authoricon })
			.setTitle(`PLEASE GIVE CREDITS AND READ THE FULL PAGE ON README.MD`)
			.setDescription(`> Replit Fork: [**Click there**](https://replit.com/@Davi99990000000/DiscordJS-V13-Uptime-Bot-prefix?v=1)
  Github repository: [**Click there**]()
	YT Tutorial: [**Click there**]`)
			.setColor(client.embed.color)
			.setFooter({ text: "This code made by: status#8108", iconURL: client.embed.footericon })
			.setTimestamp()

			let addRows = new MessageActionRow()
			 .addComponents([
				 new MessageButton()
				  .setStyle("LINK")
				  .setLabel("Replit Fork")
          .setEmoji("894607877032009758")
          .setURL(" https://replit.com/@Davi99990000000/DiscordJS-V13-Uptime-Bot-prefix#link.json"), 

				 new MessageButton()
				  .setStyle("LINK")
          .setLabel("Github repository")
				  .setEmoji("459452860795584522")
          .setURL("https://github.com/Davi99990000000/Djs-v13-Uptime-Bot-prefix-.git"), 

				 new MessageButton()
				  .setStyle("LINK")
          .setLabel("YT Tutorial")
          .setEmoji("901775783947808779")
				  .setURL("https://youtu.be/xGqE1vZ_oT8")
			 ])

			return message.reply({
				embeds: [embedSc], 
				components: [addRows]
			})
	}
}