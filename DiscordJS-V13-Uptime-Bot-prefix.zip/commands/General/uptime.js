const { MessageEmbed } = require("discord.js");

module.exports = {
	name: 'uptime',
	aliases: ["up"],
	category: "General",
	description: "Shows how long bot is running days hours minutes.",
	usage: "",
	examples: [],
	run: async (client, message, args, prefix) => {

		let days = Math.floor(client.uptime / 86400000 );
    let hours = Math.floor(client.uptime / 3600000 ) % 24;
    let minutes = Math.floor(client.uptime / 60000) % 60;
    let seconds = Math.floor(client.uptime / 1000) % 60;
		
		const embedUptime = new MessageEmbed ()
		.setTitle(`${config.emojis.check} My Uptime is:`)
		.setDescription(`Im running since days: \`${days} Days\` hours: \`${hours} Hours\` minutes: \`${minutes} Minutes\` seconds: \`${seconds} Seconds\`.`)
		.setColor(client.embed.uptimecolor)
		.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
		.setTimestamp()

		return message.reply({ embeds: [embedUptime] })
	}
			}