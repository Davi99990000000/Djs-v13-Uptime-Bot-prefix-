const { MessageEmbed } = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");


module.exports = {
    name: 'add',
    aliases: ["monitor"],
	category: "Uptime",
	description: "Add link or domain name for 27/1 host",
	usage: "add [link/domain name]",
	examples: ["add https://simply.domain.xyz"],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			if (!args[0]) {
      message.reply({
				embeds: [
					new MessageEmbed()
					 .setTitle(`${config.emojis.cross} Please provide a link or domain name!`)
			.setDescription(`Usage: **${prefix}add [link/domain name]**`)
					.setColor(client.embed.wrongcolor)
				.setTimestamp()
				]
			 })
			}
			
			let database = JSON.parse(fs.readFileSync(`${process.cwd()}/link.json`, "utf8"));
 const check = database.find(x => x.id === message.author.id);

 
    if (check) {
      if (check.link.length === 6) {
        message.reply({
					embeds: [
						new MessageEmbed()
						 .setTitle(`${config.emojis.warning} Limit reached`)
       .setDescription(`Sorry. you reached you limit of 6 urls total from database you can remove one from database by using: \`${prefix}remove\`.`)
				.setColor(client.embed.stanbycolor)
					.setTimestamp()
					]
				})
			}


			let numb = database.indexOf(check);
      database[numb].link.push(args[0]);
		} else {
			database.push({
        user_id: message.author.id,
        username: message.author.username,
        request_link: [args[0]]
      });
		}


			fs.writeFile("./link.json", JSON.stringify(database, null, 2), err => {
      
			return message.reply({
				embeds: [
					new MessageEmbed()
					 .setTitle(`${config.emojis.check} Added successfully check stats on: ${prefix}stats`)
				.setDescription(`Added To Database! thanks for using me!`)
         .setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
					.setColor(client.embed.successcolor)
					.setTimestamp()
				]
			})
	})
	}
}