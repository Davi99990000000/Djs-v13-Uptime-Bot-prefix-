const { MessageEmbed } = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");

module.exports = {
    name: 'stats',
    aliases: ["panel-stats"],
	category: "Uptime",
	description: "Shows you panel stats",
	usage: "",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			let data = JSON.parse(fs.readFileSync("./link.json", "utf8"));

			data = data.find(x => x.id === message.author.id);

			const embedDataStats = new MessageEmbed()
      .setAuthor({ name: "🔰 You panel stats", iconURL: client.embed.authoricon })
			.setTitle(`Panel hosts:`)
      .setDescription(`${config.emojis.check} | ${data.request_link.join(" ")}`)
			.setColor(client.embed.uptimecolor)
			.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
			.setTimestamp()

			message.reply({
				embeds: [
					new MessageEmbed()
					 .setTitle(`${config.emojis.checkDM} I sent a dm!`)
			.setDescription(`${message.author} Verify you **direct messages!**`)
					.setColor(client.embed.color)
					.setTimestamp()
				]
			})
			return message.author.send({
				embeds: [embedDataStats]
			}).catch(err => {
       message.channel.send({
				 content: `${config.emojis.cross} Hyy you direct messages are closed Please open you direct messages!`
			 })
			}) 
							 
	}
}