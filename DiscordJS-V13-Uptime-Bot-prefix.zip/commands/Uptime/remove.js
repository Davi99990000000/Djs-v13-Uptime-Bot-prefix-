const { MessageEmbed } = require("discord.js");
const config = require("../../config.json");
const fs = require("fs");

module.exports = {
    name: 'remove',
    aliases: ["re"],
	category: "Uptime",
	description: "Removes link/domain name from database",
	usage: "remove [link/domain name]",
	examples: ["remove https://simply.domain.xyz", "remove https://my.domain.org"],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			let database = JSON.parse(fs.readFileSync("./link.json", "utf8"));

       let data = database.find(x => x.id === message.author.id);

       let value = database.indexOf(data);
    let array = [];
    database[value].request_link.forEach((m, i) => {
      array.push(`**[${i + 1}]**: \`${m}\``);
    });

      let embed = new MessageEmbed()
      .setTitle("Please select The number of the link to remove from database")
      .setColor(client.embed.color)
      .setDescription(array.join("\n"));

    const msg = await message.channel.send({
			embeds: [embed]
		});

			let responses = await message.channel.awaitMessages(
      msg => msg.author.id === message.author.id,
      { time: 300000, max: 1 }
    );
    let repMsg = responses.first();

    if (!repMsg) {
      msg.delete();
    message.channel.send({
			content: `${config.emojis.check} successfully cancelled The Process of removing link from database!`
		})
		}

			if (isNaN(repMsg.content)) {
      msg.delete();
       message.channel.send({
				 content: `${config.emojis.cross} Cancelled The process of removing link from database. due to **invalid digit**`
			 })
			}

			if (!database[value].request_link[parseInt(repMsg.content) - 1]) {
      msg.delete();
       message.channel.send({
				 content: `${config.emojis.cross} This number from database index doesn't found.`
			 })
			}

			if (database[value].request_link.length === 1) {
      delete database[value];

      var filtered = database.filter(el => {
        return el != null && el != "";
      });

      database = filtered;
    } else {
      delete database[value].request_link[parseInt(repMsg.content) - 1];

      var filtered = database[value].link.filter(el => {
        return el != null && el != "";
      });

      database[value].request_link = filtered;
    }

    fs.writeFile("./link.json", JSON.stringify(database, null, 2), err => {
    });

    repMsg.delete();
    msg.delete();

			return message.channel.send({
				content: `${config.emojis.check} Successfully removed this number of index link from database check you stats by typing: \`${prefix}stats\``
			})
			
	}
}