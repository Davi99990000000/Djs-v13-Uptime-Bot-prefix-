const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: 'invite',
    aliases: ['inv'],
	category: "Utility",
	description: "Gives you the bot's invite link",
	usage: "invite",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			const embed = new MessageEmbed()
			 .setAuthor({ name: "Invite The Bot!", iconURL: client.embed.authoricon })
			 .setTitle(`Invite **${client.user.tag}**`)
			 .setDescription(`[**Click here**](https://discord.com/api/oauth2/authorize?client_id=${config.client.ID}&permissions=8&scope=bot) To Invite me or it's available on buttons!`)
			.setColor(client.embed.color)
			.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
			.setTimestamp() // Timestamp is very important and required for djs embeds feature. 

			const rowLink = new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setURL(`https://discord.com/api/oauth2/authorize?client_id=${config.client.ID || process.env.ID}&permissions=8&scope=bot`)
						.setLabel('Invite now')
						.setEmoji("992293031246041118")
						.setStyle('LINK'),
					  ) 
			
			return message.reply({ embeds: [embed], components: [rowLink] })
	}
}