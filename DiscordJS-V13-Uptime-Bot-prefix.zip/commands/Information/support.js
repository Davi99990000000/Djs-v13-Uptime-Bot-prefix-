const { MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: 'support',
    aliases: ['su'],
	category: "Utility",
	description: "Gives you the bot's support link",
	usage: "support",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			const embed = new MessageEmbed()
			 .setAuthor({ name: `${client.user.username}'s Support!`, iconURL: client.embed.authoricon })
			.setTitle('Join **KS DEVELOPMENT™ </>**')
			.setDescription(`[**Click here**](${config.client_links.support}) Its will redirect to bot's support it's will help us a lot! Thanks!`)
      .setColor(client.embed.color)
			.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
			.setTimestamp()

		const rowLink = new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setURL(config.client_links.support)
						.setLabel('Join bot support')
						.setEmoji("992293050204307517")
						.setStyle('LINK'),
					) 
			
			return message.reply({ embeds: [embed], components: [rowLink] })
	}
														 }