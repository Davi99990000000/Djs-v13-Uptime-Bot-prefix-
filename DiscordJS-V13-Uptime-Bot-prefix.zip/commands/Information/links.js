const { MessageEmbed } = require("discord.js");
const config = require("../../config.json");
const wait = require('node:timers/promises').setTimeout;

module.exports = {
    name: 'links',
    aliases: ["bot-links", "botlinks"],
	category: "Utility",
	description: "Shows Bot Useful links",
	usage: "",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {
		
    const embedLoadFetch = new MessageEmbed()
			.setAuthor({ name: "Loading.", iconURL: client.embed.loadingicon })
			.setTitle(`**Loading ${client.user.username}'s Links**`)
			.setDescription('Fetching bot links')
			.setColor(client.embed.stanbycolor)
      .setTimestamp()

			return message.reply({ embeds: [embedLoadFetch] }).then(async (msg) => {

			await wait(4000);

			msg.edit({
				embeds: [
					new MessageEmbed()
					
					.setAuthor({ name: `${client.user.username}'s links`, iconURL: client.embed.authoricon})
				.setTitle(`**🔗 Bot's Links:**`)
				.addFields(
					{
						name: '**Link 1**', 
						value: `Support: [**KS DEVELOPMENT™ </>**](${config.client_links.support})`
					}, 
					{
						name: '**Link 2**', 
						value: `Invite: [**${client.user.username}**](https://discord.com/api/oauth2/authorize?client_id=${config.client.ID || process.env.ID}&permissions=8&scope=bot)`
					}, 
					{
						name: '**Link 3**', 
						value: 'Soon'
					}, 
					{
						name: '**Link 4**', 
						value: 'Soon'
					}
				)
				.setColor(client.embed.color)
       .setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
				.setTimestamp()
				]
			})
		});
			
	}
						}