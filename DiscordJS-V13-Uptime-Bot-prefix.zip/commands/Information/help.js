const { MessageEmbed, MessageActionRow, MessageSelectMenu, MessageButton } = require("discord.js");
const { readdirSync } = require("fs");
const wait = require('node:timers/promises').setTimeout;
const config = require("../../config.json");
const db = require('quick.db');


module.exports = {
	name: 'help',
	aliases: ['h', 'halp', 'cmds', 'commands'],
	category: "Information",
	description: "Shows a list of commands and their functionalities.",
	usage: "help (command)",
	examples: ["help ping", "help avatar", "help mute"],
	permissions: ['SEND_MESSAGES'],
	owner: false,
	run: async (client, message, args, prefix) => {
		if (!args[0]) {

			const embed = new MessageEmbed()
				.setAuthor({ name: `${client.user.username} Help Menu | Overview`, iconURL: client.embed.authoricon })
				.setTitle('Overview Page')
				.setDescription(`Hey ${message.author} I'm **${client.user.username}** A 27/1 Uptime Host Bot by: Status+#8108           
⭐ Also my currently prefix for **${message.guild}** is: \`${prefix}\` u can get command infomation by typing: **${prefix}help [command]**`)
				.addFields(
					{
						name: "❓ __How to use me?__",
						value: `**❯** To execute a command, type: \`${prefix}[command]\`.\n**❯** Also you can mention ${client.user.tag} To get data information.`,
						inline: true
					},
					{
						name: "📈 __Client Status:__",
						value: `**❯** Prefix commands: \`${client.commands.size}\`\n`,
						inline: true
					},
					{
						name: '💎 __Bot Useful Links:__', 
						value: `> Support: [**KS DEVELOPMENT™ </>**](${config.client_links.support})                                                                                                   Invite: [**${client.user.username}**](https://discord.com/api/oauth2/authorize?client_id=${config.client.ID || process.env.ID}&permissions=8&scope=bot)                                                                                              Website: **Not Available**                                                                                                                      Bot Sponsor: **null**`
					}
				)
				.setFooter({ text: `Requested By: ${message.author.tag}`, iconURL: client.embed.footericon })
				.setColor(client.embed.color)
        .setTimestamp();
			
			const emojis = {
				Information: "1013222635745837106", 
				General: "992293015739703416", 
				Uptime: "933944283826888734"
			};

			// Buttons:
			const rowButtonsHomeDisabled = new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setCustomId('help_menu_button_home')
						.setEmoji('🏠')
						.setDisabled(true)
						.setLabel('Main Menu')
						.setStyle('PRIMARY'),
					new MessageButton()
						.setCustomId('help_menu_button_stop')
						.setEmoji('🗑️')
						.setLabel('Delete')
						.setStyle('DANGER'),
				);

			const rowButtons = new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setCustomId('help_menu_button_home')
						.setEmoji('🏠')
						.setLabel('Main Menu')
						.setStyle('PRIMARY'),
					new MessageButton()
						.setCustomId('help_menu_button_stop')
						.setEmoji('🗑️')
						.setLabel('Delete')
						.setStyle('DANGER'),
				);

			const rowButtonsAllDisabled = new MessageActionRow()
				.addComponents(
					new MessageButton()
						.setCustomId('help_menu_button_home')
						.setEmoji('🏠')
						.setLabel('Main Menu')
						.setDisabled(true)
						.setStyle('PRIMARY'),
					new MessageButton()
						.setCustomId('help_menu_button_stop')
						.setEmoji('🗑️')
						.setLabel('Delete')
						.setDisabled(true)
						.setStyle('DANGER'),
				);

			// Prefix commands menu:
			const rowMenu = new MessageActionRow()
				.addComponents([
					new MessageSelectMenu()
						.setCustomId("help-menu")
						.setPlaceholder("Click here to select a category!")
						.addOptions([
							client.categories.map((cat) => {
								return {
									label: `${cat[0].toUpperCase() + cat.slice(1)}`,
									value: cat,
									emoji: emojis[cat] || "❔",
									description: `Click here to see ${cat}'s commands.`
								}
							})
						])
				]);

			// If the collector ends, then this menu shows up:
			const rowMenuDisabled = new MessageActionRow()
				.addComponents([
					new MessageSelectMenu()
						.setCustomId("help-menu-disabled")
						.setPlaceholder("Timeout")
						.setDisabled(true)
						.addOptions({
							label: `ERR`,
							value: "ERR",
							description: `ERR`
						})
				]);

			message.reply({ embeds: [embed], components: [rowMenu, rowButtonsHomeDisabled] }).then(async (msg) => {

				// Buttons collector:
				let filterButtons = (i) => i.user.id === message.member.id;
				const collectorButtons = await msg.createMessageComponentCollector({
					filter: filterButtons,
					type: "BUTTON"
				})
				collectorButtons.on("collect", async (i) => {
					if (i.customId === "help_menu_button_home") {
						msg.edit({ embeds: [embed], components: [rowMenu, rowButtonsHomeDisabled] }).catch(() => { });
					}
					if(i.customId === "help_menu_button_stop") {
						msg.delete().catch(() => { });
					}
				});

				// Select menu collector:
				const filterMenu = i => i.user.id === message.member.id;
				const collectorMenu = await msg.createMessageComponentCollector({
					filter: filterMenu,
					type: "SELECT_MENU",
					time: 300000
				});
				collectorMenu.on('collect', async (col) => {
					await col.deferUpdate().catch(() => { });

					try {
						const [directory] = col.values;

						const embedCommand = new MessageEmbed()
							.setAuthor({ name: `${client.user.username} Help Menu | Category: ${directory}`, iconURL: client.user.displayAvatarURL() })
							.setTitle(`*All commands for the category __${directory}__:*`)
							.setDescription(`The current prefix for **${message.guild.name}** is \`${prefix}\`.`)
							.addFields(
								client.commands.filter(cmd => cmd.category === directory).map((cmd) => {
									if (cmd) {
										return {
											name: `${cmd.name ? `• \`${prefix}${cmd.name}\`:` : "• unknown.js"}`,
											value: `${cmd.description ? `${cmd.description}` : "> No description for that command."}`,
											inline: true
										}
									} else {
										return {
											name: `No commands for this directory.`,
											value: `** **`
										}
									}
								})
							)
							.setFooter({ text: `Requested By: ${message.author.tag}`, iconURL: client.embed.footericon })
							.setColor(client.embed.color)
						  .setTimestamp();

						msg.edit({ embeds: [embedCommand], components: [rowMenu, rowButtons] });
					} catch (e) {

					}
				});

				collectorMenu.on('end', async () => {
					const embedExpired = new MessageEmbed()
						.setTitle("__***Help section timeout***__")
						.setThumbnail(client.embed.authoricon)
						.addFields(
                {
                name: ':pinkstar: **Command Timeout**', 
								value: `> **This help menu is expired! Please retype \`${prefix}help\` to view again.**`, 
								inline: true
                } 
              )   
						.setFooter({ text: `Requested By: ${message.author.tag}`, iconURL: client.embed.footericon })
						.setColor(client.embed.color)
					  .setTimestamp();

					msg.edit({ embeds: [embedExpired], components: [rowMenuDisabled, rowButtonsAllDisabled] }).catch(() => { });
				});

			});

			// if {prefix}help (command):
		} else {

			const command =
				client.commands.get(args[0].toLowerCase()) ||
				client.commands.find(
					(c) => c.aliases && c.aliases.includes(args[0].toLowerCase())
				);

			if (!command) {
				const embed = new MessageEmbed()
					.setDescription(`${config.emojis.cross} Couldn't find that command it's was removed or unavailable, try to run the command \`${prefix}help\`.`)
					.setColor(client.embed.wrongcolor);

				return message.reply({ embeds: [embed] }).then(async (timeout) => {
					await wait(5000);
					message.delete().catch(() => { });
					timeout.delete().catch(() => { });
				})

			} else {

				const embed = new MessageEmbed()
					.setAuthor({ name: `${client.user.username} Help Menu | Command Information`, iconURL: client.embed.authoricon })
					.setTitle(`Command information: ${prefix}${command.name}`)
					.setDescription("There are two types of arguments when using one of the commands:\n`[...]`: Argument is **required**.\n`(...)`: Argument is **not required**.")
					.addFields(
						{ name: "• Command description:", value: command.description ? command.description : "[No description for this command]", inline: true },
						{ name: "• Command aliase(s):", value: command.aliases ? `${command.aliases.map(al => `\`${prefix}${al}\``).join(", ") || "[No aliases for this command]"}` : "[No aliases for this command]", inline: true },
						{ name: "• Command permissions(s):", value: command.permissions ? `\`${command.permissions.join(", ")}\`.` : "[No permissions for this command]", inline: true },
						{ name: "• Command category:", value: command.category ? `${command.category}` : "[No category for this command]", inline: true },
						{ name: "• Command usage:", value: command.usage ? `\`${prefix}${command.usage}\`` : `[No usage for this command]`, inline: true },
						{ name: "• Developers only?", value: command.owner ? "Yes." : "No.", inline: true },
						{ name: "• Command example(s):", value: command.examples.map(cmd => `\`${prefix}${cmd}\``).join(" | ") || "[No examples for this command]", inline: false },
					)
					.setFooter({ text: `To see ${client.user.username} commands type: ${prefix}help`, iconURL: client.embed.footericon })
					.setColor(client.embed.color)
				  .setTimestamp();

				return message.reply({ embeds: [embed] });

			}
		}
	}
					}