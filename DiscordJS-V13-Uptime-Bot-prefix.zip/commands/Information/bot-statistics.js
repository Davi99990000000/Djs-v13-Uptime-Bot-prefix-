const { MessageEmbed, version } = require("discord.js");
const config = require("../../config.json");
const os = require("os");
const cpuStat = require("cpu-stat");

module.exports = {
    name: 'bot-statistics',
    aliases: ["bot-stats", "bot-status"],
	category: "Information",
	description: "Shows bot's statistics",
	usage: "",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {

			cpuStat.usagePercent(function (err, percent, seconds) {

			const embed1 = new MessageEmbed()
    .setTitle(`**${config.emojis.check} ${client.user.username}'s Statistics**`)
			.setDescription(`[*Click there to join support!*](${config.client_links.support})`)
				.addFields([
					{
						name: '🤖 Username', 
						value: `${client.user.username}`, 
					}, 
					{
						name: '🤖 Id', 
						value: `${config.client.ID || process.env.ID}`
					}, 
					{
						name: '📦 Discord.JS', 
            value: `${version}`
					}, 
					{
						name: '📂 Channels', 
						value: `\`${client.channels.cache.size}\``
					}, 
					{
						name: '🤖 Memory', 
						value: `${(process.memoryUsage().heapUsed / 1024 / 1024 ).toFixed(2)}\` / \`${(os.totalmem() / 1024 / 1024).toFixed(2)} MB\``
					}, 
					{
						name: '🤖 Uptime', 
						value: `<t:${Math.floor(
                  Date.now() / 1000 - client.uptime / 1000)}:R>`
					}, 
					{
						name: '📂 Guild', 
						value: `\`${client.guilds.cache.size}\``
					}, 
					{
						name: '🤖 Ping', 
						value: `\`${client.ws.ping}ms\``
					}, 
					{
						name: '🤖 Message Latency', 
						value: `\`${message.createdTimestamp - message.createdTimestamp}ms\``
					}, 
					{
            name: '🤖 Node', 
						value: `${process.version}`
					}, 
					{
						name: '🤖 CPU', 
						value: `\`\`\`md\n${os.cpus().map((i) => `${i.model}`)[0]}\`\`\``
					}, 
					{
						name: '🤖 CPU usage', 
						value: `\`${percent.toFixed(2)}%\``
					}, 
					{
						name: '🤖 Arch', 
						value: `\`${os.arch()}\``
					}, 
					{
						name: '🤖 Platform', 
						value: `\`\`${os.platform()}\`\``
					}
				])
				.setColor(client.embed.color)
				.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
				.setTimestamp()

			return message.channel.send({
				embeds: [embed1]
			})
	}) 
			
	}
}