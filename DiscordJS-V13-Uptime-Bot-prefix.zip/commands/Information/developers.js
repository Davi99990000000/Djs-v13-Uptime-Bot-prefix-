const { MessageEmbed } = require("discord.js");
const config = require("../../config.json");

module.exports = {
    name: 'developers',
    aliases: ["devs", "owners"],
	category: "Information",
	description: "Bot gives you information who is the bot developer",
	usage: "",
	examples: [],
    permissions: ['SEND_MESSAGES'],
	owner: false,
    run: async(client, message, args, prefix) => {
		
      const embed = new MessageEmbed()
			.setAuthor({ name: 'Developers', iconURL: client.embed.authoricon })
			.setDescription(`Hey ${message.author} My developer & owners is:
	 
Name: **Status+#8108**
Developer Id: **960995553968271410**
Their Badges: <:active_developer:1045037708407488592> **Active Developer**
Ping: <@960995553968271410>
Server Owner: At [**KS DEVELOPMENT™ </>**](https://discord.gg/UsFFUMnYRB)
Their Best Friends: <@770988400047947796>, <@610513919601279005>`)
			.setColor(client.embed.color)
		.setFooter({ text: client.embed.footertext, iconURL: client.embed.footericon })
		.setTimestamp()

			return message.channel.send({ embeds: [embed] })
	}
				}