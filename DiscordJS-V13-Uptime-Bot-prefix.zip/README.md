# DISCORD.JS V14 HAS BEEN RELEASED.
This project is will be**no longer supported** to future but still working on v13, 

# 📝 Quick Start:
> **how i can get bot token**

> first you have to go the [discord's developers portal](https://discord.com/developers) go to create application go to bot > reset bot token and put token on config.json or the secrets

> **how i can get bot id(client.id)**

> go to bot > oauth2 > client id and copy bot id put in config.json only

# 📝 Requirements on config.json
> the requirements are:

> TOKEN, ID(CLIENT ID), SUPPORT(DISCORD INVITE)

# 📝 Please read before use the code 
> this code is created by: status+#8108 and support by KS DEVELOPMENT™ </> please give us credits for code if you are not interested without credits you will get copyright strike for not giving us credits (example showing for YouTube channel video of project)

# 🤖 Our Bots 
> First one is KS Up -- Prime#2673 it's a uptime bot with djs v13 example this exact bot it's using this code poblamy I can share the bot token the bot token are on secrets. their prefix `>>`

> and secondary bot is KS Tickety Bot#9803 it's a advanced ticketing bot with djs v13 with mongodb token required also this code still on test but it's not available to share it on everyone but their prefix `t!` also it's ready with slash commands

> and third bot is all in one bot called Application Test#2485 poblamy it's not ready to share this bot code also new bot name I will be coming soon. this bot it's packed with best features like `image, settings(setup), moderation, utility, fun, information, antiswear, welcome system, and more...` their prefix `-` also it's ready with slash commands!

thanks for reading this file it's very important to start the bot code. 

powered by: KS DEVELOPMENT™ </> | Coding community


my youtube: **https://tinyurl.com/2s4ry829**

join KS DEVELOPMENT™ </> | Coding community: [**https://discord.gg/ksdevelopment**](https://discord.gg/UsFFUMnYRB)